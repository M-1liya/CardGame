﻿namespace CardGame.Assets.Util
{
    internal class GameConst
    {
        public const int MAX_COUNT_HANDDECK = 5;

        public const int BASE_HEALTH_NEXUS = 20;
        public const int BASE_HEALTH_PLAYER = 1;
        public const int BASE_MANA_PLAYER = 1;
        public const int BASE_COUNT_ROUND = 1;

    }
}
