﻿namespace CardGame.Assets.Model.Cards.CardType
{
    public enum PotionType
    {
        HEALTH,
        DAMAGE,
    }

}
