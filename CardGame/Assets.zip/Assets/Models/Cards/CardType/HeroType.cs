﻿namespace CardGame.Assets.Model.Cards.CardType
{
    public enum HeroType
    {
        DRAGON,
        PRINCESS,
        SHREK,
        DONKEY,
        KNIGHT,
    }
}
