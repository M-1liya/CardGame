﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGame.Assets.Models
{
    public enum BattleStatus
    {
        ATTACK = 1,
        PROTECTION,
    }
}
