﻿using CardGame.Assets.Model.Cards;

namespace CardGame.Assets.Model.Factories
{
    public interface ICardFactory
    {
        abstract Card create(Enum type);
    }
}
