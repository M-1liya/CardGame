﻿
using CardGame.Assets.Model.Cards;
using CardGame.Assets.Model.Cards.CardType;
using CardGame.Assets.Models;
using CardGame.Assets.Models.Cards;
using System.Collections.Generic;
using System.Drawing.Text;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace CardGame.Assets
{
    public static class Fight
    {
        static Dictionary<BattleStatus, Player?> FightPlayers = new Dictionary<BattleStatus, Player?>();
        public static Dictionary<string, Player> Start(Dictionary<string, Player> Players)
        {
            foreach (var player in Players)
            {
                FightPlayers[player.Value.BattleStatus] = player.Value;

                foreach (var card in new List<Card>(player.Value.Deck.OnBattleground))
                    if (card is Potion)
                        castPotion(player.Value.Deck.OnBattleground, (Potion)card);
            }
            foreach (var player in FightPlayers)
                if (player.Value == null)
                    throw new Exception("Battle status of players must be different!");


            var DataAttack = new Dictionary < DeckType, List<Card>>() 
            {
                { DeckType.ATTACKDECK, FightPlayers[BattleStatus.ATTACK].Deck.OnBattleground },
                { DeckType.DEFENDDECK, FightPlayers[BattleStatus.PROTECTION].Deck.OnBattleground },
            };

            if (DataAttack[DeckType.ATTACKDECK].Count == 0) return Players;

            FightAlgoritm(DataAttack);

            if (FightPlayers[BattleStatus.PROTECTION].HealthNexus <= 0) return null;

            Game.resetPlayersMana(Players.Values.ToList());

            return Players;
        }

        //Теперь за один бой герои наносят по одному удару
        //Наносит урон нексусу только атакующий
        //при условии что его никто не блокирует 
        private static void FightAlgoritm(Dictionary<DeckType, List<Card>> DataAttack)
        {
            for(int i = 0; i < DataAttack[0].Count; i++)
            {
                if (i > DataAttack[DeckType.DEFENDDECK].Count-1)
                    FightPlayers[BattleStatus.PROTECTION].HealthNexus -= ((Hero)DataAttack[DeckType.ATTACKDECK][i]).Damage;

                else
                {
                    ((Hero)DataAttack[DeckType.ATTACKDECK][i]).Health -= ((Hero)DataAttack[DeckType.DEFENDDECK][i]).Damage;
                    ((Hero)DataAttack[DeckType.DEFENDDECK][i]).Health -= ((Hero)DataAttack[DeckType.ATTACKDECK][i]).Damage;
                }
            }

            foreach(var Cards in DataAttack)
                foreach(var card in new List<Card>(Cards.Value))
                    if (((Hero)card).Health <= 0)
                        DataAttack[Cards.Key].Remove(card);
        }

        public static void castPotion(List<Card> Cards, Potion potion)
        {

            foreach (var card in Cards)
            {
                if (card is Hero)
                {
                    if (((Hero)card).TypeHero == potion.Hero)
                    {
                        switch (potion.TypePotion)
                        {
                            case PotionType.DAMAGE:
                                ((Hero)card).Damage += potion.Effect; break;
                            case PotionType.HEALTH:
                                ((Hero)card).Health += potion.Effect; break;
                        }
                        break;
                    }
                }
            }
            Cards.Remove(potion);
        }

    }
}
