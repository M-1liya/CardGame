using CardGame.Assets;
using CardGame.Assets.Model.Factories;
using CardGame.Assets.Models;
using CardGame.Assets.Model.Cards.CardType;

namespace CardGameTests
{
    [TestClass]
    public class FightTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            Dictionary<string, Player> Players = new Dictionary<string, Player>()
            {
                { "P1", new Player(BattleStatus.ATTACK) },
                { "P2", new Player(BattleStatus.PROTECTION) },
            };
            ICardFactory heroFactory = new HeroFactory();
            Players["P1"].Deck.OnBattleground.Add(heroFactory.create(HeroType.DRAGON));
            Players["P1"].Deck.OnBattleground.Add(heroFactory.create(HeroType.SHREK));

            Players["P2"].Deck.OnBattleground.Add(heroFactory.create(HeroType.DONKEY));
            Players["P2"].Deck.OnBattleground.Add(heroFactory.create(HeroType.DONKEY));

            Fight.Start(Players);
            return;
        }
    }
}